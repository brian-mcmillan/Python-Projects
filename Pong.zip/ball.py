from turtle import Turtle, Screen

class Ball(Turtle):
    def __init__(self):
        super().__init__()

        self.penup()
        self.color('white')
        self.shape('circle')

        self.xinc = 10
        self.yinc = 10

    def move(self):
        new_x = self.xcor() + self.xinc
        new_y = self.ycor() + self.yinc
        self.goto(new_x, new_y)

    def bounce_y(self):
        self.yinc *= -1

    def bounce_x(self):
        self.xinc *= -1

    def reset(self):
        self.goto(0,0)
        self.bounce_x()


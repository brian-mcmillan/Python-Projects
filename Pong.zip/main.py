from turtle import Turtle, Screen
from paddle import Paddle
from ball import Ball
from scoreboard import Scoreboard
import time

screen = Screen()
screen.bgcolor('black')
screen.setup(width = 800, height = 600)
screen.title("Pong")
screen.tracer(0)


screen.listen()
rPad = Paddle(350, 0)
lPad = Paddle(-350, 0)
ball = Ball()
score = Scoreboard()
screen.onkey(rPad.up, "Up")
screen.onkey(rPad.down, "Down")
screen.onkey(lPad.up, "w")
screen.onkey(lPad.down, "s")


game_on = True
x = 0.1
while game_on:
    time.sleep(x)
    screen.update()
    ball.move()

    if ball.ycor() > 280 or ball.ycor() < -280:
        ball.bounce_y()

    if ball.distance(rPad) < 50 and ball.xcor() > 340 or ball.distance(lPad) < 50 and ball.xcor() < - 340:
        ball.bounce_x()
        x -= 0.01

    if ball.xcor() > 380:
        ball.reset()
        x = 0.1
        score.l_point()

    if ball.xcor() < -380:
        ball.reset()
        x = 0.1
        score.r_point()

    if score.l_score == 1:
        winner = Turtle()
        winner.color("white")
        winner.goto(-50,0)
        winner.write("Left Paddle has won.")
        game_on = False

    if score.r_score == 1:
        winner = Turtle()
        winner.color("white")
        winner.goto(-50,0)
        winner.write("Right Paddle has won.")
        game_on = False



screen.exitonclick()
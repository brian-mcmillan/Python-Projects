# NATO Project to work with list comprehension
import pandas, time

# read.csv
df = pandas.read_csv('nato_phonetic_alphabet.csv')

# create dictionary of letter, value pairs from dataframe
phonetic = {row.letter: row.code for (index, row) in df.iterrows()}
#print(phonetic)

# EX:
#{"A": "Alfa", "B": "Bravo"}

# translate message

user = input("Enter a word: ").upper()

input_list = [char for char in user]
#print(input_list)

print("\ntranslating your message..."), time.sleep(0.5)

output_list = [phonetic[char] for char in input_list]
print(f"\n{output_list}")
import time
from turtle import Screen

import car_manager
from player import Player
from car_manager import CarManager
from scoreboard import Scoreboard

screen = Screen()
screen.setup(width=600, height=600)
screen.tracer(0)
screen.listen()

player = Player()
cars = CarManager()
score = Scoreboard()
screen.onkey(player.up, "w")

game_is_on = True
while game_is_on:
    time.sleep(0.1)
    screen.update()

    cars.create()
    cars.move()

    for car in cars.car_list:
        if car.distance(player) < 20:
            game_is_on = False
            score.game_over()

    if player.ycor() > 290:
        score.add_score()
        player.reset()
        car_manager.STARTING_MOVE_DISTANCE += car_manager.MOVE_INCREMENT
















screen.exitonclick()
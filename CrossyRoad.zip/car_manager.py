from turtle import Turtle, Screen
import random


COLORS = ["red", "orange", "yellow", "green", "blue", "purple"]
STARTING_MOVE_DISTANCE = 5
MOVE_INCREMENT = 2

class CarManager:

    def __init__(self):
        self.car_list = []


    def create(self):
        random_chance = random.randint(1,6)
        if random_chance == 1:

            car = Turtle("square")
            car.penup()
            car.color(COLORS[random.randint(0, 5)])
            car.shapesize(1, 3)
            start_y = random.randint(-240, 280)
            start_x = 280
            car.goto(start_x, start_y)
            self.car_list.append(car)

    def move(self):
        for car in self.car_list:
            car.new_x = car.xcor() - STARTING_MOVE_DISTANCE
            car.new_y = car.ycor()
            car.goto(car.new_x, car.new_y)




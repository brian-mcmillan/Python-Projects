from turtle import Turtle, Screen
import pandas

screen = Screen()
screen.title("U.S. States Game")
img = "blank_states_img.gif"
screen.addshape(img)

turtle = Turtle()
turtle.penup()
turtle.shape(img)

df = pandas.read_csv("50_states.csv")
state_list = list(df["state"])

current_state = Turtle()
current_state.hideturtle()
current_state.penup()

score = Turtle()
score.penup()
score.hideturtle()
score.goto(-40, 250)

amount_correct = 0
score.write(f"{amount_correct} / 50", font=('Arial', 30, 'bold'))

game_is_on = True
while game_is_on:
    answer = screen.textinput(title = "Guess A State", prompt="Name a state: ")
    answer = answer.lower()

    if answer == "exit":
        feedback_data = pandas.DataFrame(state_list)
        feedback_data.to_csv("states_to_learn.csv")
        print(feedback_data)
        break

    for state in df.state:
        if state.lower() == answer.lower():
            correct_guess = df[df.state == state]
            current_state.goto(int(correct_guess.x), int(correct_guess.y))
            current_state.write(state, font=('Arial', 8, 'bold'))
            state_list.remove(state)

            amount_correct += 1

            score.clear()
            score.write(f"{amount_correct} / 50", font=('Arial', 30, 'bold'))


    if len(state_list) == 0:
        game_is_on = False
        win = Turtle()
        win.penup()
        win.hideturtle()
        win.goto(-50, 0)
        win.color("green")
        win.write("You Win", font=('Arial', 30, 'bold'))



screen.exitonclick()

from turtle import Turtle, Screen
import pandas


class guessed_state(Turtle):

    def __init__(self):
        super().__init__()
        self.penup()

    def correct_guess(self):
        if

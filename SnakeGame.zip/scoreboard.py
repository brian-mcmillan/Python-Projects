from turtle import Turtle, Screen


class Scoreboard(Turtle):

    def __init__(self):
        super().__init__()
        self.penup()
        self.hideturtle()
        self.color("white")
        self.goto(0, 280)
        self.score = 0
        self.write("Score = 0")

    def game_over(self):
        self.goto(0, 0)
        self.write("Game Over")

    def update(self):
        self.clear()
        self.score += 1
        self.write(f"Score = {self.score}")


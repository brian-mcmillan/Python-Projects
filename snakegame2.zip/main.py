from turtle import Screen, Turtle
import time
from snake import Snake
from food import Food
from scoreboard import Scoreboard

# Screen
screen = Screen()
screen.setup(width=590, height=590)
screen.bgcolor("black")
screen.tracer(0)
screen.title("Snake")

snake = Snake()
food = Food()
score = Scoreboard()

screen.listen()
screen.onkey(snake.up, "Up")
screen.onkey(snake.left, "Left")
screen.onkey(snake.right, "Right")
screen.onkey(snake.down, "Down")

game_on = True
while game_on:
    screen.update()
    time.sleep(0.1)
    snake.move()

    # Collision detection - Food
    if snake.head.distance(food) < 15:
        food.refresh()
        snake.extend()
        score.increase_score()

    # Collision detection - Wall
    if snake.head.xcor() > 280 or snake.head.xcor() < -280 or snake.head.ycor() > 280 or snake.head.ycor() < -280:
        score.update()
        score.reset()
        snake.reset()
    # Collision detection - Tail
    for segment in snake.segments[1:]:
        if snake.head.distance(segment) < 10:
            score.update()
            score.reset()
            snake.reset()


screen.exitonclick()
